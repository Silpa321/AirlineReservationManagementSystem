package com.mypackage.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Bankserver;
import com.mypackage.demo.repository.BankserverRepository;
import com.mypackage.demo.service.BankserverService;



@Service
public class BankserverServiceImpl implements BankserverService{

	
	@Autowired
	private BankserverRepository bankserverRepositry;
	
	@Override
	public Bankserver saveDetails(Bankserver bankserver) {
		
		return bankserverRepositry.save(bankserver);
	}
	@Override
	public Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber,String expiryDate) {
		return bankserverRepositry.findByCardCvv(cCardnumber, cCvvnumber, expiryDate);
	}
	
	@Override
	public Bankserver findByUpi(String cUpi) {
		
		return bankserverRepositry.findByUpi(cUpi);
	}
	
}
