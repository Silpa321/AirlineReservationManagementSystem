package com.mypackage.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mypackage.demo.model.Passenger;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger,Integer> {
	
	 @Query(value = "SELECT p.* FROM passenger_table p JOIN reservation_table r ON p.reservation_id = r.reservation_id WHERE r.reservation_number = ?1", nativeQuery = true)
	  public List<Passenger> findPassengersByReservationNumber(String reservationNumber);
	 
	 List<Passenger> findByReservation_RId(int rId);
}
