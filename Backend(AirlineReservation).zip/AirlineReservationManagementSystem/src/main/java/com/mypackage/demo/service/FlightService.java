package com.mypackage.demo.service;

import java.util.List;

import com.mypackage.demo.model.Flight;

public interface FlightService {
	public Flight addFlight(Flight flight);
	
	public List<Flight> getallFlight();
	public Flight getFlightById(int flightId);
	public void removeFlightById(int flightId);
	public Flight updateFlightById(int flightId,Flight flight);
	
	public List<Flight> searchFlightsByFromAndTo(String departureAirport, String arrivalAirport);
}

