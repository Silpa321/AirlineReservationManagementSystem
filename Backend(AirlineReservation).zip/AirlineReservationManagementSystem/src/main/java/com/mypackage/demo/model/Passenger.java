package com.mypackage.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Passenger_Table")
public class Passenger {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Passenger_Id")
	private int pId;
	
	@Column(name="FirstName")
	private String pFirstName;
	
	@Column(name="LastName")
	private String pLastName;
	
	@Column(name="Email")
	private String pEmail;
	
	@Column(name="MobileNo")
	private String pMobileNo;
	@Column(name="Age")
	private Integer pAge;
	@Column(name="Gender")
	private String pGender;
	@Column(name="seatNumber")
	private String pSeatNumber;
	@Column(name="PassportNo")
	private String pPassportNo;
	/*@Column(name="flightId")
	private int pflightId;*/
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="User_Id",nullable=false)//Foreign key in Passenger table column named by user_id and ensures that this is not null means it is not accepting null values
	private User user;
	

	/*@OneToMany(mappedBy = "passenger", cascade = CascadeType.ALL)
	private List<Reservation> reservations;*/
	@JsonIgnoreProperties({"passengers", "flight", "user"})
	@ManyToOne
	@JoinColumn(name = "reservation_id", referencedColumnName = "reservation_id")
    private Reservation reservation;

	
	
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpFirstName() {
		return pFirstName;
	}
	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}
	public String getpLastName() {
		return pLastName;
	}
	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}
	public String getpEmail() {
		return pEmail;
	}
	public void setpEmail(String pEmail) {
		this.pEmail = pEmail;
	}
	public String getpMobileNo() {
		return pMobileNo;
	}
	public void setpMobileNo(String pMobileNo) {
		this.pMobileNo = pMobileNo;
	}
	public String getpPassportNo() {
		return pPassportNo;
	}
	public void setpPassportNo(String pPassportNo) {
		this.pPassportNo = pPassportNo;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	/*public List<Reservation> getReservations() {
		return reservations;
	}
	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}*/
	public Integer getpAge() {
		return pAge;
	}
	public void setpAge(Integer pAge) {
		this.pAge = pAge;
	}
	public String getpGender() {
		return pGender;
	}
	public void setpGender(String pGender) {
		this.pGender = pGender;
	}
	
	public String getpSeatNumber() {
		return pSeatNumber;
	}
	public void setpSeatNumber(String pSeatNumber) {
		this.pSeatNumber = pSeatNumber;
	}
	public Reservation getReservation() {
		return reservation;
	}
	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}
	/*public int getFlightId() {
		return pflightId;
	}
	public void setFlightId(int flightId) {
		this.pflightId = flightId;
	}*/

	
	
	
}
