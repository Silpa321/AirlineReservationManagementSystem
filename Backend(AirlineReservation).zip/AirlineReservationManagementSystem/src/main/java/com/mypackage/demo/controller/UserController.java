package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.User;
import com.mypackage.demo.service.UserService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping
	public ResponseEntity<User> addUser(@RequestBody User user){
		return new ResponseEntity<User> (userService.addUser(user),HttpStatus.CREATED);
	}
	@GetMapping
	public List<User> findAllStudent(){
		return userService.getAllUsers();
	}
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") int userId){
		return new ResponseEntity<User> (userService.getUserById(userId),HttpStatus.OK);
	}
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> removeUserById(@PathVariable("userId") int userId){
		userService.removeUserById(userId);
		return new ResponseEntity<String>("Deleted SuccessFully",HttpStatus.OK);
	}
	@DeleteMapping("/getUserafterremoving/{userId}")
	public List<User> removeUserById1(@PathVariable("userId") int userId){
		userService.removeUserById(userId);
		return userService.getAllUsers();
	}
	@PutMapping("/{userId}")
	public ResponseEntity<User> updateUserById(@PathVariable("userId") int userId,@RequestBody User user){
		return new ResponseEntity<User> (userService.updateUserById(userId, user),HttpStatus.OK);
	}
	@PostMapping("/login")
	public ResponseEntity<User> login(@RequestBody User user){
		System.out.println(user);
		return new ResponseEntity<User>(userService.login(user),HttpStatus.OK);
		
	}
	@GetMapping("/findbyemail/{userEmail}")
	public ResponseEntity<User> findUserbyEmail(@PathVariable("userEmail") String userEmail){
		return new ResponseEntity<User>(userService.findByEmail(userEmail),HttpStatus.OK);
	}
	@GetMapping("/findbyMobileNo/{userMobileNo}")
	public ResponseEntity<User> findUserbyMobileNo(@PathVariable("userMobileNo") String userMobileNo){
		return new ResponseEntity<User>(userService.findByMobileNo(userMobileNo),HttpStatus.OK);
	}
	@GetMapping("/findbymailandfav/{userEmail}/{userFavourite}")
	public ResponseEntity<User> findUserBymailandFav(@PathVariable("userEmail") String userEmail,@PathVariable("userFavourite") String userFavourite){
		return new ResponseEntity<User>(userService.findByEmailandFav(userEmail, userFavourite),HttpStatus.OK);
	}
	
	@PutMapping("/updatenewpass/{userEmail}/{npass}")
	public void updatePassByMail(@PathVariable("userEmail") String userEmail,@PathVariable("npass") String newPassword) {
		userService.updatepassByMail(userEmail,newPassword);
	}
	@PutMapping("/updateUseByEmail/{userEmail}")
	public void updateUserByEmail(@PathVariable("userEmail") String userEmail,@RequestBody User user){
		userService.updateUserByEmail(userEmail, user);
	}
}
