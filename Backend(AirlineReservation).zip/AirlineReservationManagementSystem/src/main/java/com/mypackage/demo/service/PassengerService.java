package com.mypackage.demo.service;

import java.util.List;

import com.mypackage.demo.model.Passenger;

public interface PassengerService {
	public Passenger addPassenger(Passenger passenger);
	public Passenger addPassengerToUser(Passenger passenger,int userId);
	public List<Passenger> addPassengersToUser(List<Passenger> passenger,int userId,int flightId);
	public List<Passenger> getAllPassenger();
	public Passenger getPassengerById(int pId);
	public void removePassengerById(int pId);
	public Passenger updatePassengerById(int pId,Passenger passenger);
	
	public List<Passenger> getPassengersByReservationNumber(String reservationNumber);
	
	

	
}
