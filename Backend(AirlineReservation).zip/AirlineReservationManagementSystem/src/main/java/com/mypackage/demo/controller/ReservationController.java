package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.CombinedResponseDTO;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.service.ReservationService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/Reservation")
public class ReservationController {
	@Autowired 
	ReservationService reservationService;
	@PostMapping
	public ResponseEntity<Reservation> addReservation(@RequestBody Reservation reservation){
		return new ResponseEntity<Reservation> (reservationService.addReservation(reservation),HttpStatus.CREATED);
	}
	@GetMapping
	public List<Reservation> getAllReservations(){
		return reservationService.getAllReservation();
	}
	@GetMapping("/{rId}")
	public ResponseEntity<Reservation> getReservationById(@PathVariable("rId") int rId){
		return new ResponseEntity<Reservation>(reservationService.getReservationById(rId),HttpStatus.OK);
	}
	@DeleteMapping("/{rId}")	
	public ResponseEntity<String> removeReservationById(@PathVariable("rId") int rId){
		reservationService.removeReservationById(rId);
		return new ResponseEntity<String>("Deleted Successfully!!",HttpStatus.OK);
	}
	@DeleteMapping("/getReservationafterdelete/{rId}")	
	public List<Reservation> removeReservationById1(@PathVariable("rId") int rId){
		reservationService.removeReservationById(rId);
		return reservationService.getAllReservation();
	}
	@PutMapping("/{rId}")
	public ResponseEntity<Reservation> updateReservationById(@PathVariable("rId") int rId,@RequestBody Reservation reservation){
		return new ResponseEntity<Reservation> (reservationService.updateReservationById(rId, reservation),HttpStatus.OK);
	}
    @GetMapping("/{userId}/passengers")
    public List<Passenger> getPassengers(@PathVariable("userId") int userId,@RequestBody Passenger passenger) {
        return reservationService.getPassengersByUser(userId);
    }
	/*@GetMapping("/{rId}/passengers")
	public List<Passenger> getPassengersByReservationId(@PathVariable("rId") int rId,@RequestBody Passenger passenger ){
		return reservationService.getPassengersByReservationId(rId);
	}*/
    
    @GetMapping("/reservation-summary/{reservationNumber}")
    public ResponseEntity<CombinedResponseDTO> getReservationSummary(@PathVariable String reservationNumber) {
    	CombinedResponseDTO summary = reservationService.getReservationDetailsByReservationNumber(reservationNumber);
    	System.out.println(summary);
        return ResponseEntity.ok(summary);
    }
    
    @GetMapping("/reservation-summary/{userId}")
    public ResponseEntity<CombinedResponseDTO> getReservationSummarybyUserId(@PathVariable("userId") String reservationNumber) {
    	CombinedResponseDTO summary = reservationService.getReservationDetailsByReservationNumber(reservationNumber);
    	System.out.println(summary);
        return ResponseEntity.ok(summary);
    }
    
    @GetMapping("/by-user-id/{userId}")
    public List<CombinedResponseDTO> getReservationsByUserId(@PathVariable int userId) {
        return  reservationService.getReservationDetailsByUserId(userId);
    }
}
