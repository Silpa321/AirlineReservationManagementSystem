package com.mypackage.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineReservationManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineReservationManagementSystemApplication.class, args);
	}

}
