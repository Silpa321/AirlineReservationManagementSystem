package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.Flight;

import com.mypackage.demo.service.FlightService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/flight")

public class FlightController {
	@Autowired
	FlightService flightService;

	
	@PostMapping
	public ResponseEntity<Flight> addFlight(@RequestBody Flight flight){
		
		return new ResponseEntity<Flight> (flightService.addFlight(flight),HttpStatus.CREATED);
	}
	
	@GetMapping
	public List<Flight> getAllFlight(){
		return flightService.getallFlight();
	}
	@GetMapping("/{flightId}")
	public ResponseEntity<Flight> getFlightById(@PathVariable("flightId") int flightId){
		return new ResponseEntity<Flight> (flightService.getFlightById(flightId),HttpStatus.OK);
	}
	@DeleteMapping("/{flightId}")
	public ResponseEntity<String> removeFlightById(@PathVariable("flightId") int flightId){
		flightService.removeFlightById(flightId);
		return new ResponseEntity<String> ("Deleted Successfully!!",HttpStatus.OK);
	}
	
	@DeleteMapping("/getflightsafterdeleting/{flightId}")
	public List<Flight> removeFlightById1(@PathVariable("flightId") int flightId){
		flightService.removeFlightById(flightId);
		return flightService.getallFlight();
	}
	@PutMapping("/{flightId}")
	public ResponseEntity<Flight> updateFlightById(@PathVariable("flightId") int flightId,@RequestBody Flight flight){
		return new ResponseEntity<Flight> (flightService.updateFlightById(flightId, flight),HttpStatus.OK);
	}
	@GetMapping("/search/{from}/{to}")
	public List<Flight> searchFlights(@PathVariable("from") String departureAirport,@PathVariable("to") String arrivalAirport) {
	    return flightService.searchFlightsByFromAndTo(departureAirport, arrivalAirport);
	}
}
