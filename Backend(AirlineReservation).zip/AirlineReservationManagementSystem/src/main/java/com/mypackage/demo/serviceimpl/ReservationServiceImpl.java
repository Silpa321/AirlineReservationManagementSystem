package com.mypackage.demo.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.CombinedResponseDTO;
import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.model.User;
import com.mypackage.demo.repository.FlightRepository;
import com.mypackage.demo.repository.PassengerRepository;
import com.mypackage.demo.repository.ReservationRepository;
import com.mypackage.demo.repository.UserRepository;

import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.ReservationService;
import com.mypackage.demo.service.UserService;

@Service
public class ReservationServiceImpl implements ReservationService {
	@Autowired
	ReservationRepository reservationRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private PassengerService passengerService;
	
	 @Autowired
	    private PassengerRepository passengerRepository;
	 @Autowired
	 FlightService flightService;
	 @Autowired
	 FlightRepository flightRepository;

	
	@Override
	public Reservation addReservation(Reservation reservation) {
		// TODO Auto-generated method stub
		return reservationRepository.save(reservation);
	}
	

	@Override
	public List<Reservation> getAllReservation() {
		// TODO Auto-generated method stub
		return reservationRepository.findAll();
	}

	@Override
	public Reservation getReservationById(int rId) {
		// TODO Auto-generated method stub
		return reservationRepository.findById(rId).get();
	}

	@Override
	public void removeReservationById(int rId) {
		// TODO Auto-generated method stub
		Reservation reservation=getReservationById(rId);
		reservationRepository.deleteById(rId);
		
	}

	@Override
	public Reservation updateReservationById(int rId, Reservation newReservationDetails) {
		// TODO Auto-generated method stub
		Reservation existingReservationInfo=getReservationById(rId);
		return reservationRepository.save(existingReservationInfo);
	}

	@Override
	public List<Passenger> getPassengersByUser(int user_Id) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(user_Id);
		return user.getPassenger();
	}


	@Override
	public CombinedResponseDTO getReservationDetailsByReservationNumber(String reservationNumber) {
		// TODO Auto-generated method stub
		Reservation reservation = reservationRepository.findByReservationNumber(reservationNumber);

	    if (reservation == null) {
	        throw new RuntimeException("Reservation not found with number: " + reservationNumber);
	    }

	    // Fetch passengers
	    List<Passenger> passengers = passengerRepository.findByReservation_RId(reservation.getrId());

	    // Fetch flight
	    Flight flight = flightRepository.findById(reservation.getFlight().getFlightId())
	            .orElse(null);

	    CombinedResponseDTO responseDTO = new CombinedResponseDTO();
	    responseDTO.setReservationNumber(reservation.getReservationNumber());

	    // Passenger DTO mapping
	    List<CombinedResponseDTO.PassengerDTO> passengerDTOs = passengers.stream().map(p -> {
	        CombinedResponseDTO.PassengerDTO dto = new CombinedResponseDTO.PassengerDTO();
	        dto.setFirstName(p.getpFirstName());
	        dto.setLastName(p.getpFirstName());
	        dto.setEmail(p.getpEmail());
	        dto.setSeatNumber(p.getpSeatNumber());
	        return dto;
	    }).collect(Collectors.toList());
	    responseDTO.setPassengers(passengerDTOs);

	    // Flight DTO mapping
	    if (flight != null) {
	        CombinedResponseDTO.FlightDTO flightDTO = new CombinedResponseDTO.FlightDTO();
	        flightDTO.setFlightCode(flight.getFlightCode());
	        flightDTO.setDepartureTime(flight.getDepartureTime());
	        flightDTO.setArrivalTime(flight.getArrivalTime());
	        flightDTO.setDepartureAirport(flight.getDepartureAirport());
	        flightDTO.setArrivalAirport(flight.getArrivalAirport());
	        responseDTO.setFlight(flightDTO);
	    }

	    return responseDTO;
	}
	 
	@Override
    public List<CombinedResponseDTO> getReservationDetailsByUserId(int userId) {
        // Fetch all reservations by user ID
        List<Reservation> reservations = reservationRepository.findByUser_userId(userId);

        List<CombinedResponseDTO> responseDTOs = new ArrayList<>();

        for (Reservation reservation : reservations) {
            List<Passenger> passengers = passengerRepository.findByReservation_RId(reservation.getrId());
            Flight flight = flightRepository.findById(reservation.getFlight().getFlightId()).orElse(null);

            CombinedResponseDTO responseDTO = new CombinedResponseDTO();
            responseDTO.setReservationNumber(reservation.getReservationNumber());

            // Map passengers to DTO
            List<CombinedResponseDTO.PassengerDTO> passengerDTOs = passengers.stream().map(p -> {
                CombinedResponseDTO.PassengerDTO dto = new CombinedResponseDTO.PassengerDTO();
                dto.setFirstName(p.getpFirstName());
                dto.setLastName(p.getpLastName());
                dto.setEmail(p.getpEmail());
                dto.setSeatNumber(p.getpSeatNumber());
                return dto;
            }).collect(Collectors.toList());
            responseDTO.setPassengers(passengerDTOs);

            // Map flight details to DTO
            if (flight != null) {
                CombinedResponseDTO.FlightDTO flightDTO = new CombinedResponseDTO.FlightDTO();
                flightDTO.setFlightCode(flight.getFlightCode());
                flightDTO.setDepartureTime(flight.getDepartureTime());
                flightDTO.setArrivalTime(flight.getArrivalTime());
                flightDTO.setDepartureAirport(flight.getDepartureAirport());
                flightDTO.setArrivalAirport(flight.getArrivalAirport());
                responseDTO.setFlight(flightDTO);
            }

            responseDTOs.add(responseDTO);
        }

        return responseDTOs;
    }
	   
	
}
