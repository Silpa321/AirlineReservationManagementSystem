package com.mypackage.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mypackage.demo.model.CombinedResponseDTO;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.repository.ReservationRepository;



public interface ReservationService {
	public Reservation addReservation(Reservation reservation);
	public List<Reservation> getAllReservation();
	public void removeReservationById(int rId);
	public Reservation updateReservationById(int rId,Reservation newReservationDetails);
	public Reservation getReservationById(int rId);
	public List<Passenger> getPassengersByUser(int user_Id);
	//public List<Passenger> getPassengersByReservationId(int rId);
	public CombinedResponseDTO getReservationDetailsByReservationNumber(String reservationNumber);
	
	public List<CombinedResponseDTO> getReservationDetailsByUserId(int userId);
}
