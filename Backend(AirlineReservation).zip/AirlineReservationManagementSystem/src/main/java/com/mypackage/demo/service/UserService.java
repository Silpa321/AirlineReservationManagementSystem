package com.mypackage.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mypackage.demo.model.User;

public interface UserService {
	public User login(User user);//findbyUserEmailandUserpassword
	public User addUser(User user);
	public List<User> getAllUsers();
	public User getUserById(int userId);
	public void removeUserById(int userId);
	public User updateUserById(int userId,User user);
	public void updateUserByEmail(String userEmail,User user);
	
	public User findByEmail(String userEmail);
	public User findByMobileNo(String userMobileNo);
	public User findByEmailandFav(String userEmail,String userFavourite);
	public void updatepassByMail(String userEmail, String newPassword);
}
