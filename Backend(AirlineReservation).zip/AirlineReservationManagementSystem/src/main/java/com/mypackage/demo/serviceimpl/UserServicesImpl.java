package com.mypackage.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.User;
import com.mypackage.demo.repository.UserRepository;
import com.mypackage.demo.service.UserService;

@Service
public class UserServicesImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId).get();
	}

	@Override
	public void removeUserById(int userId) {
		// TODO Auto-generated method stub
		User user=getUserById(userId);
		userRepository.deleteById(user.getUserId());
	}

	@Override
	public User updateUserById(int userId, User newUserDetails) {
		// TODO Auto-generated method stub
		User existingUserInfo=getUserById(userId);
		existingUserInfo.setUserFirstName(newUserDetails.getUserFirstName());
		existingUserInfo.setUserLastName(newUserDetails.getUserLastName());
		existingUserInfo.setUserMobileNo(newUserDetails.getUserMobileNo());
		existingUserInfo.setUserEmail(newUserDetails.getUserEmail());
		existingUserInfo.setUserAge(newUserDetails.getUserAge());
		existingUserInfo.setUserGender(newUserDetails.getUserGender());
		existingUserInfo.setUserPassword(newUserDetails.getUserPassword());
		existingUserInfo.setUserPassportNo(newUserDetails.getUserPassportNo());
		return userRepository.save(existingUserInfo);
	}

	@Override
	public User login(User user) {
		// TODO Auto-generated method stub
		return userRepository.findByUserEmailAndUserPassword(user.getUserEmail(), user.getUserPassword());
	}

	@Override
	public User findByEmail(String userEmail) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(userEmail).get();
	}

	@Override
	public User findByMobileNo(String userMobileNo) {
		// TODO Auto-generated method stub
		return userRepository.finfByPhone(userMobileNo);
	}

	@Override
	public User findByEmailandFav(String userEmail, String userFavourite) {
		// TODO Auto-generated method stub
		return userRepository.findByEmailAndFav(userEmail, userFavourite);
	}

	@Override
	public void updatepassByMail(String userEmail, String newPassword) {
		// TODO Auto-generated method stub
		userRepository.updatepassByMail(userEmail, newPassword);
		
	}

	@Override
	public void updateUserByEmail(String userEmail,User user) {
		// TODO Auto-generated method stub
		userRepository.updateUserByEmail(user.getUserFirstName(), user.getUserLastName(), user.getUserMobileNo(), user.getUserPassword(), user.getUserPassportNo(), userEmail, user);;
		
	}

	

	

}
