package com.mypackage.demo.service;

import com.mypackage.demo.model.Bankserver;

public interface BankserverService {
	
	 public Bankserver saveDetails(Bankserver bankserver);

	 public Bankserver findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate);

	Bankserver findByUpi(String cUpi);
}
