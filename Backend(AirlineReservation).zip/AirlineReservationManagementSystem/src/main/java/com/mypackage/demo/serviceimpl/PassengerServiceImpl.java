package com.mypackage.demo.serviceimpl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Flight;
import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.model.Reservation;
import com.mypackage.demo.model.Seat;
import com.mypackage.demo.model.User;
import com.mypackage.demo.repository.PassengerRepository;
import com.mypackage.demo.repository.ReservationRepository;
import com.mypackage.demo.repository.UserRepository;
import com.mypackage.demo.service.FlightService;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.SeatService;
import com.mypackage.demo.service.UserService;

import jakarta.transaction.Transactional;

@Service
public class PassengerServiceImpl implements PassengerService{
	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private SeatService seatService;
	
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private ReservationRepository reservationRepository;

	@Override
	public Passenger addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(passenger);
	}
	@Override
	public Passenger addPassengerToUser(Passenger passenger,int UserId) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(UserId);
		passenger.setUser(user);
		return passengerRepository.save(passenger);
	}
	
	@Transactional
	@Override
	public List<Passenger> addPassengersToUser(List<Passenger> passengers, int userId, int flightId) {
	    // Step 1: Fetch the User and Flight
	    User user = userService.getUserById(userId);
	    Flight flight = flightService.getFlightById(flightId);

	    if (user == null || flight == null) {
	        throw new IllegalArgumentException("User or Flight not found");
	    }

	    // Step 2: Create and save the Reservation entity
	    Reservation reservation = new Reservation();
	    reservation.setReservationNumber(UUID.randomUUID().toString().substring(0, 8).toUpperCase());
	    reservation.setUser(user);
	    reservation.setFlight(flight);
	    reservation = reservationRepository.save(reservation); // Save the reservation

	    // Step 3: Link each passenger to the user and the reservation
	    for (Passenger passenger : passengers) {
	        passenger.setUser(user);         // Ensure user is set
	        passenger.setReservation(reservation); // Ensure reservation is set
	        System.out.println("Passenger details: " + passenger.getpFirstName() + ", " + passenger.getpLastName() + ", " + passenger.getpSeatNumber());
	    }

	    // Step 4: Save passengers to database
	    List<Passenger> savedPassengers = passengerRepository.saveAll(passengers);

	    // Step 5: Book the seats
	    for (Passenger passenger : savedPassengers) {
	        String seatNumber = passenger.getpSeatNumber();
	        if (seatNumber != null) {
	            seatService.markSeatAsBooked(seatNumber, flightId);
	        }
	    }

	    return savedPassengers;
	}


	@Override
	public List<Passenger> getAllPassenger() {
		// TODO Auto-generated method stub
		return passengerRepository.findAll();
	}

	@Override
	public Passenger getPassengerById(int pId) {
		// TODO Auto-generated method stub
		return passengerRepository.findById(pId).get();
	}

	@Override
	public void removePassengerById(int pId) {
		// TODO Auto-generated method stub
		Passenger passenger=getPassengerById(pId);
		passengerRepository.deleteById(pId);
		
	}

	@Override
	public Passenger updatePassengerById(int pId, Passenger newpassengerDetails) {
		// TODO Auto-generated method stub
		Passenger existingPassengerInfo=getPassengerById(pId);
		existingPassengerInfo.setpFirstName(newpassengerDetails.getpFirstName());
		existingPassengerInfo.setpLastName(newpassengerDetails.getpLastName());
		existingPassengerInfo.setpEmail(newpassengerDetails.getpEmail());
		existingPassengerInfo.setpMobileNo(newpassengerDetails.getpMobileNo());
		existingPassengerInfo.setpAge(newpassengerDetails.getpAge());
		existingPassengerInfo.setpGender(newpassengerDetails.getpGender());
		existingPassengerInfo.setpPassportNo(newpassengerDetails.getpPassportNo());
		return passengerRepository.save(existingPassengerInfo);
	}
	
	
	 @Override
	    public List<Passenger> getPassengersByReservationNumber(String reservationNumber) {
	        return passengerRepository.findPassengersByReservationNumber(reservationNumber);
	    }
	 
	 
	

	 }

	
