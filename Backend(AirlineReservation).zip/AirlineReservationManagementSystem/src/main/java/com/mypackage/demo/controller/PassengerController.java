package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.service.PassengerService;
import com.mypackage.demo.service.SeatService;
import com.mypackage.demo.service.UserService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api/passenger")
public class PassengerController {
	@Autowired
	private PassengerService passengerService;
	
	@Autowired 
	private UserService userService;
	
	@Autowired 
	private SeatService seatService;
	
	@PostMapping
	public ResponseEntity<Passenger> addPassenger(@RequestBody Passenger passenger){
		return new ResponseEntity<Passenger> (passengerService.addPassenger(passenger),HttpStatus.CREATED);
	}
	
	
	@PostMapping("/{userId}")
	public ResponseEntity<Passenger> addPassengerToUser(@PathVariable("userId") int userId,@RequestBody Passenger passenger){
		return new ResponseEntity<Passenger> (passengerService.addPassengerToUser(passenger, userId),HttpStatus.CREATED);
	}
	
	
	@PostMapping("/passengers/{userId}/{flightId}")
	public List<Passenger> addPassengersToUser(@PathVariable("userId") int userId,@PathVariable("flightId") int flightId,@RequestBody List<Passenger> passengers){
		  for (Passenger p : passengers) {
		        System.out.println("Received Passenger: " + p.getpFirstName() + ", " + p.getpSeatNumber());
		    }
		return  passengerService.addPassengersToUser(passengers, userId,flightId);
	}
	
	
	@GetMapping
	public List<Passenger> getAllPassenger(){
		return passengerService.getAllPassenger();
	}
	
	
	
	@GetMapping("/{pId}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable("pId") int pId) {
		return new ResponseEntity<Passenger> (passengerService.getPassengerById(pId),HttpStatus.OK);
	}
	
	
	@DeleteMapping("/{pId}")
	public ResponseEntity<String> removePassengerById(@PathVariable("pId") int pId){
		passengerService.removePassengerById(pId);
		return new ResponseEntity<String> (" Passenger Deleted SuccessFully",HttpStatus.OK);
	}
	
	@GetMapping("/getPassengerafterDelete/{pId}")
	public List<Passenger> removePassengerById1(@PathVariable("pId") int pId){
		passengerService.removePassengerById(pId);
		return passengerService.getAllPassenger();
	}
	
	
	@PutMapping("/{pId}")
	public ResponseEntity<Passenger> updatePassengerById(@PathVariable("pId") int pId,@RequestBody Passenger passenger){
		return new ResponseEntity<Passenger> (passengerService.updatePassengerById(pId, passenger),HttpStatus.OK);
	}
	
	
	 @GetMapping("/byreservation/{reservationNumber}")
	    public List<Passenger> getPassengersByReservationNumber(@PathVariable("reservationNumber") String reservationNumber) {
	        return passengerService.getPassengersByReservationNumber(reservationNumber);
	    }
	 
	 /*@PostMapping("/update-payment")
	 public ResponseEntity<String> updatePayment(@RequestParam String reservationNumber, @RequestParam String paymentId) {
	     passengerService.updatePaymentIdForReservation(reservationNumber, paymentId);
	     return ResponseEntity.ok("Payment ID updated for all passengers.");
	 }*/
}
