package com.mypackage.demo.service;

import java.util.List;

import com.mypackage.demo.model.Seat;

public interface SeatService {
	public Seat addSeat(Seat seat);
	public Seat addSeatToFlight(Seat seat,int flightId);
	public List<Seat> addSameSeatMultipleTimes(List<Seat> seat, int flightId, int count);
	public List<Seat> getAllSeats();
	public Seat getSeatById(int seatId);
	public void removeSeatById(int seatId);
	public Seat updateSeatById(int seatId,Seat seat);
	
	//public void updatePassengerBySeatid(int seatId,int seatPassengerId);
	public List<Seat> getSeatsByFlightId(int flightId);
	
	public Seat updateSeatByFlightId(int flightId, int seatId, Seat newSeatDetails);

	public Seat updateSeatStatusbySeatNumberofFlight(int flightId,String seatNumber,Seat newSeatDetails);
	
	
	public void deleteSeatByFlightId(int flightId, int seatId);
	
	public void markSeatAsBooked(String seatNumber, int flightId);

}
