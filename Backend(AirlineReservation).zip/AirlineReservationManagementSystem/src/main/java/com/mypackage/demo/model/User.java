package com.mypackage.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="UserTable")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="User_Id")
	private int userId;
	@Column(name="FisrtName",nullable=false)
	private String userFirstName;
	@Column(name="LastName",nullable=false)
	private String userLastName;
	@Column(name="EmailAddress",nullable=false,unique=true)
	private String userEmail;
	@Column(name="MobileNo",nullable=false,unique=true)
	private String userMobileNo;
	@Column(name="Gender")
	private String userGender;
	@Column(name="Age",nullable=true)
	private Integer userAge;
	@Column(name="favourite")
	private String userFavourite;
	@Column(name="Password",nullable=false,unique=true)
	private String userPassword;
	@Column(name="PassportNo",nullable=false,unique=true)
	private String userPassportNo;
	
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL)
	@JsonIgnore
	private List<Passenger> passenger;
	
	
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<Reservation> reservations;

	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobileNo() {
		return userMobileNo;
	}
	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserPassportNo() {
		return userPassportNo;
	}
	public void setUserPassportNo(String userPassportNo) {
		this.userPassportNo = userPassportNo;
	}
	public List<Passenger> getPassenger() {
		return passenger;
	}
	public void setPassenger(List<Passenger> passenger) {
		this.passenger = passenger;
	}
	
	public String getUserFavourite() {
		return userFavourite;
	}
	public void setUserFavourite(String userFavourite) {
		this.userFavourite = userFavourite;
	}
	
	public String getUserGender() {
		return userGender;
	}
	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userEmail=" + userEmail + ", userMobileNo=" + userMobileNo + ", userFavourite=" + userFavourite
				+ ", userPassword=" + userPassword + ", userPassportNo=" + userPassportNo + ", passenger=" + passenger
				+ "]";
	}
	
	
}
